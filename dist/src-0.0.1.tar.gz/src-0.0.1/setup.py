from setuptools import setup,find_packages

setup(
    name = "src",
    version = "0.0.1",description = "it is a wine quality package",
    author = "ravi441",
    packages = find_packages(),
    license = "MIT"
)
#
# you_numpy
#    you_numpy
#    __init__